SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `#__volunteers_departments`;
DROP TABLE IF EXISTS `#__volunteers_members`;
DROP TABLE IF EXISTS `#__volunteers_positions`;
DROP TABLE IF EXISTS `#__volunteers_reports`;
DROP TABLE IF EXISTS `#__volunteers_roles`;
DROP TABLE IF EXISTS `#__volunteers_teams`;
DROP TABLE IF EXISTS `#__volunteers_volunteers`;

SET FOREIGN_KEY_CHECKS = 1;